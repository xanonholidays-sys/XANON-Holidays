# XANON HOLIDAYS — GitHub-ready website

## Files
- `index.html` — public premium website + trip registration
- `admin.html` — private registration dashboard
- `supabase.sql` — database table and RLS policies
- `assets/` — the four uploaded XANON reference images

## 1. Supabase
Create a Supabase project.
Run `supabase.sql` in SQL Editor.
Create an Auth user for yourself.
Replace `YOUR_ADMIN_EMAIL` in the SQL with that exact email.

## 2. Add Supabase keys
In BOTH `index.html` and `admin.html`, replace:
`YOUR_SUPABASE_PROJECT_URL`
`YOUR_SUPABASE_PUBLISHABLE_KEY`

Use the project's publishable key. Never put a secret/service-role key in these HTML files.

## 3. GitHub Pages
Create a GitHub repository and upload all files/folders.
Make sure `index.html` is in the repository root.
Then enable GitHub Pages from Settings > Pages and publish from the main branch/root.
Your site will be available at your GitHub Pages URL.

## 4. Edit trip details
The four sample trips, prices, dates and descriptions are directly in `index.html`.
Replace them with your real XANON HOLIDAYS itinerary before publishing.

## 5. Admin
Open `/admin.html` on your GitHub Pages site and log in with your Supabase Auth account.
